<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - Home</title>
</head>
<body>
<!-- Header -->
<?php include '../partial/header.php'; ?>
<!-- Header -->
<!-- Main Banner -->
<section class="banner banner-in sec-before custom-website">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 dis-flex">
				<h1 class="heading-two">Stunning product design
				to flawless code.<br>
				<strong>We help you win!</strong></h1>
				<p class="para-one">Creating top-class websites, mobile apps and
				brand identity</p>
				<ul class="list-unstyled">
					<li class="list-inline-item mr-4"><div class="btn-span"><a href="/" class="btn bg btn-smart">Let’s Talk</a></div></li>
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Explore More</a></li>
				</ul>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<div class="img-box cirlce-in">
					<img src="/assets/images/custom-web-banner.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->
<!-- Logos One -->
<section class="logos-one">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<div class="img-box">
					<img src="/assets/images/logos-img.jpg" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Logos One -->
<!-- About -->
<section class="about">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-5 col-lg-5 ">
				<div class="img-box">
					<img src="/assets/images/about-img-2.jpg" class="img-fluid" alt="">
				</div>
			</div>
			<div class="col-sm-12 col-md-7 col-lg-7 back-color">
				<h2 class="heading-two text-grad">Inteligent digital experiance that build brands and grow businesses</h2>
				<p class="para-two">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-6 dis-flex-start">
						<a href="#" class="btn btn-simple">Explore more</a>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-6">
						<img src="/assets/images/about-logo.jpg" class="img-fluid" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About -->
<!-- Website Services -->
<section class="web-service">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-two text-center mb6">Website desigin and development services</h2>
			</div>
			<div class="row">
				<div class="col-lg-6">
					<div class="img-box"><img src="/assets/images/b2b/type-img.jpg" class="img-fluid" alt=""></div>
				</div>
				<div class="col-lg-6 dis-flex">
					<h2 class="heading-three style-li">Custom Websites Development</h2>
					<p class="para-two">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.
					</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Website Services -->
<!-- Portfolio -->
<?php include '../partial/portfolio.php'; ?>
<!-- Portfolio -->
<!-- Platform Logos -->
<section class="platform sec-before">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 dis-flex">
				<p class="para-one">As a full-service design agency,
					we work closely with our clients to define,
					design, and develop transformative user
					experiences across all platforms and
				brand’s touch points.</p>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<ul class="list-unstyled pl-logos">
					<li><img src="/assets/images/ecommerce/logo-1.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-2.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-3.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-4.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-5.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-6.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-7.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-8.png" alt=""></li>
					<li><img src="/assets/images/ecommerce/logo-9.png" alt=""></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Platform Logos -->
<!-- Experience -->
<section class="experience">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<h2 class="heading-two mb2 style-li">Industries Experience</h2>
				<ul class="list-unstyled ex-icons">
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-1.png" alt="">Marketing Agencies</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-2.png" alt="">Banking & Finance</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-3.png" alt="">Retail & E-Commerce</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-4.png" alt="">Education and E-Learning</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-5.png" alt="">Healthcare Hospital</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-6.png" alt="">Logistics & Transportation</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-7.png" alt="">Automotive Eng</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-8.png" alt="">Technology Science</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-9.png" alt="">Media & Entertainment</li>
					<li class="style-li"><img src="/assets/images/ecommerce/ex-icon-10.png" alt="">Travel & Tourism</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Experience -->
<!-- Pricing -->
<?php include '../partial/pricing.php'; ?>
<!-- Pricing -->
<!-- Let's Talk -->
<section class="lets-talk">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-three">We have Digital Solution for Everyone <strong>Let’s help you find more clients and grow your Business</strong></h2>
				<ul class="list-unstyled mb-0 mt-5">
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Talk</a></li>
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Get Started</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Let's Talk -->
<!-- Testimonial -->
<?php include '../partial/testimonials.php'; ?>
<!-- Testimonial -->
<!-- Footer -->
<?php include '../partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script -->