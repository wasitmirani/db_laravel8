		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js" ></script>
		<script src="" ></script>
		<!-- <script src="assets/js/slim.min.js" ></script> -->
		<script src="/assets/js/custom.js"></script>
		<script src="/assets/js/fancybox.js"></script>
		<script src="/assets/js/bootstrap.bundle.min.js"></script>
		<!-- Option 2: jQuery, Popper.js, and Bootstrap JS -->
		<script src="/assets/js/popper.min.js"></script>
		<script src="/assets/js/bootstrap.min.js"></script>
		<script src="/assets/js/slick.min.js"></script>
	</body>
</html>