<section class="pricing sec-before">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-two text-center mb1">Pricing Plans that Work for You!</h2>
				<p class="para-one text-center mb5">Offering a range of competitive custom design packages <br> designed for your business needs</p>
			</div>	
		</div>
		<div class="row mb-5">
				<div class="col-lg-4">
					<div class="box">
						<div class="box-head">
							<h2 class="text-grad"><strong>Platinum</strong> Package</h2>
							<p class="para-two">Best Value for Money Guaranteed!</p>
							<h3 class="price">$399 <span>only</span> <strong>$1299</strong></h3>
						</div>
						<div class="box-body">
							<ul class="list-unstyled">
								<li>- Unlimited Logo Concepts (8 Initial Concepts)</li>
								<li>- 5 Dedicated Designers</li>
								<li>- UNLIMITED Revisions</li>
								<li>- FREE Custom Stationery Design</li>
								<li>- FREE MS Word Letterhead</li>
								<li>- Free Email Signature</li>
								<li>- 48 Hours Turnaround Time</li>
								<li>- FREE Icon Design</li>
							</ul>
							<a href="#" class="btn btn-simple">Order Now</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="box">
						<div class="box-head">
							<h2 class="text-grad"><strong>Platinum</strong> Package</h2>
							<p class="para-two">Best Value for Money Guaranteed!</p>
							<h3 class="price">$399 <span>only</span> <strong>$1299</strong></h3>
						</div>
						<div class="box-body">
							<ul class="list-unstyled">
								<li>- Unlimited Logo Concepts (8 Initial Concepts)</li>
								<li>- 5 Dedicated Designers</li>
								<li>- UNLIMITED Revisions</li>
								<li>- FREE Custom Stationery Design</li>
								<li>- FREE MS Word Letterhead</li>
								<li>- Free Email Signature</li>
								<li>- 48 Hours Turnaround Time</li>
								<li>- FREE Icon Design</li>
							</ul>
							<a href="#" class="btn btn-simple">Order Now</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="box">
						<div class="box-head">
							<h2 class="text-grad"><strong>Platinum</strong> Package</h2>
							<p class="para-two">Best Value for Money Guaranteed!</p>
							<h3 class="price">$399 <span>only</span> <strong>$1299</strong></h3>
						</div>
						<div class="box-body">
							<ul class="list-unstyled">
								<li>- Unlimited Logo Concepts (8 Initial Concepts)</li>
								<li>- 5 Dedicated Designers</li>
								<li>- UNLIMITED Revisions</li>
								<li>- FREE Custom Stationery Design</li>
								<li>- FREE MS Word Letterhead</li>
								<li>- Free Email Signature</li>
								<li>- 48 Hours Turnaround Time</li>
								<li>- FREE Icon Design</li>
							</ul>
							<a href="#" class="btn btn-simple">Order Now</a>
						</div>
					</div>
				</div>
			</div>
			<div class="row text-center">
			<div class="btn-span m-auto"><a href="/" class="btn bg btn-smart">View All Packages</a></div>
		</div>
	</div>
</section>