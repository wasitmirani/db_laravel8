<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - Home</title>
</head>
<body>
<!-- Header -->
<?php include '../partial/header.php'; ?>
<!-- Header -->
<!-- Main Banner -->
<section class="banner banner-in">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 ">
				<h1 class="heading-one">Pricing</h1>
				<p class="para-one">WDP Web Designs is a high-end, full-service digital design agency delivering seamless web design and development services.</p>
				<div class="btn-span"><a href="/" class="btn bg btn-smart">get a free quote</a></div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<div class="img-box ">
					<img src="/assets/images/banner-side-img.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->
<!-- Portfolio -->
<?php include '../partial/pricing.php'; ?>
<!-- Portfolio -->
<!-- Footer -->
<?php include '../partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script -->